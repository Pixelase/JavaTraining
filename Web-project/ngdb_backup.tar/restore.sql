--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.work_request DROP CONSTRAINT fk_work_type_id;
ALTER TABLE ONLY public.employee DROP CONSTRAINT fk_work_type_employee_id;
ALTER TABLE ONLY public.work_request DROP CONSTRAINT fk_work_scope_id;
ALTER TABLE ONLY public.brigade DROP CONSTRAINT fk_work_request_id;
ALTER TABLE ONLY public.work_request DROP CONSTRAINT fk_tenant_id;
ALTER TABLE ONLY public.brigade_member DROP CONSTRAINT fk_employee_id;
ALTER TABLE ONLY public.brigade_member DROP CONSTRAINT fk_brigade_id;
ALTER TABLE ONLY public.tenant DROP CONSTRAINT fk_address_id;
ALTER TABLE ONLY public.work_type DROP CONSTRAINT pk_work_type_id;
ALTER TABLE ONLY public.work_scope DROP CONSTRAINT pk_work_scope_id;
ALTER TABLE ONLY public.work_request DROP CONSTRAINT pk_work_request_id;
ALTER TABLE ONLY public.tenant DROP CONSTRAINT pk_tenant_id;
ALTER TABLE ONLY public.employee DROP CONSTRAINT pk_employee_id;
ALTER TABLE ONLY public.brigade_member DROP CONSTRAINT pk_brigade_member_id;
ALTER TABLE ONLY public.brigade DROP CONSTRAINT pk_brigade_id;
ALTER TABLE ONLY public.address DROP CONSTRAINT pk_address_id;
ALTER TABLE public.work_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.work_scope ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.work_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tenant ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.employee ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.brigade ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.address ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.work_type_id_seq;
DROP TABLE public.work_type;
DROP SEQUENCE public.work_scope_id_seq;
DROP TABLE public.work_scope;
DROP SEQUENCE public.work_request_id_seq;
DROP TABLE public.work_request;
DROP SEQUENCE public.tenant_id_seq;
DROP TABLE public.tenant;
DROP SEQUENCE public.employee_id_seq;
DROP TABLE public.employee;
DROP TABLE public.brigade_member;
DROP SEQUENCE public.brigade_id_seq;
DROP TABLE public.brigade;
DROP SEQUENCE public.address_id_seq;
DROP TABLE public.address;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: address; Type: TABLE; Schema: public; Owner: pixelase; Tablespace: 
--

CREATE TABLE address (
    id integer NOT NULL,
    street character varying,
    house character varying,
    apartment character varying
);


ALTER TABLE address OWNER TO pixelase;

--
-- Name: address_id_seq; Type: SEQUENCE; Schema: public; Owner: pixelase
--

CREATE SEQUENCE address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE address_id_seq OWNER TO pixelase;

--
-- Name: address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pixelase
--

ALTER SEQUENCE address_id_seq OWNED BY address.id;


--
-- Name: brigade; Type: TABLE; Schema: public; Owner: pixelase; Tablespace: 
--

CREATE TABLE brigade (
    id integer NOT NULL,
    real_date date,
    work_request_id integer
);


ALTER TABLE brigade OWNER TO pixelase;

--
-- Name: brigade_id_seq; Type: SEQUENCE; Schema: public; Owner: pixelase
--

CREATE SEQUENCE brigade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE brigade_id_seq OWNER TO pixelase;

--
-- Name: brigade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pixelase
--

ALTER SEQUENCE brigade_id_seq OWNED BY brigade.id;


--
-- Name: brigade_member; Type: TABLE; Schema: public; Owner: pixelase; Tablespace: 
--

CREATE TABLE brigade_member (
    brigade_id integer NOT NULL,
    employee_id integer NOT NULL
);


ALTER TABLE brigade_member OWNER TO pixelase;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: pixelase; Tablespace: 
--

CREATE TABLE employee (
    id integer NOT NULL,
    first_name character varying,
    last_name character varying,
    work_type_id integer,
    salary bigint
);


ALTER TABLE employee OWNER TO pixelase;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: pixelase
--

CREATE SEQUENCE employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE employee_id_seq OWNER TO pixelase;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pixelase
--

ALTER SEQUENCE employee_id_seq OWNED BY employee.id;


--
-- Name: tenant; Type: TABLE; Schema: public; Owner: pixelase; Tablespace: 
--

CREATE TABLE tenant (
    id integer NOT NULL,
    first_name character varying,
    last_name character varying,
    address_id integer
);


ALTER TABLE tenant OWNER TO pixelase;

--
-- Name: tenant_id_seq; Type: SEQUENCE; Schema: public; Owner: pixelase
--

CREATE SEQUENCE tenant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tenant_id_seq OWNER TO pixelase;

--
-- Name: tenant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pixelase
--

ALTER SEQUENCE tenant_id_seq OWNED BY tenant.id;


--
-- Name: work_request; Type: TABLE; Schema: public; Owner: pixelase; Tablespace: 
--

CREATE TABLE work_request (
    id integer NOT NULL,
    work_type_id integer,
    work_scope_id integer,
    desired_date date,
    tenant_id integer
);


ALTER TABLE work_request OWNER TO pixelase;

--
-- Name: work_request_id_seq; Type: SEQUENCE; Schema: public; Owner: pixelase
--

CREATE SEQUENCE work_request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE work_request_id_seq OWNER TO pixelase;

--
-- Name: work_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pixelase
--

ALTER SEQUENCE work_request_id_seq OWNED BY work_request.id;


--
-- Name: work_scope; Type: TABLE; Schema: public; Owner: pixelase; Tablespace: 
--

CREATE TABLE work_scope (
    id integer NOT NULL,
    name character varying,
    employees_count integer
);


ALTER TABLE work_scope OWNER TO pixelase;

--
-- Name: work_scope_id_seq; Type: SEQUENCE; Schema: public; Owner: pixelase
--

CREATE SEQUENCE work_scope_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE work_scope_id_seq OWNER TO pixelase;

--
-- Name: work_scope_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pixelase
--

ALTER SEQUENCE work_scope_id_seq OWNED BY work_scope.id;


--
-- Name: work_type; Type: TABLE; Schema: public; Owner: pixelase; Tablespace: 
--

CREATE TABLE work_type (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE work_type OWNER TO pixelase;

--
-- Name: work_type_id_seq; Type: SEQUENCE; Schema: public; Owner: pixelase
--

CREATE SEQUENCE work_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE work_type_id_seq OWNER TO pixelase;

--
-- Name: work_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pixelase
--

ALTER SEQUENCE work_type_id_seq OWNED BY work_type.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY address ALTER COLUMN id SET DEFAULT nextval('address_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY brigade ALTER COLUMN id SET DEFAULT nextval('brigade_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY employee ALTER COLUMN id SET DEFAULT nextval('employee_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY tenant ALTER COLUMN id SET DEFAULT nextval('tenant_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY work_request ALTER COLUMN id SET DEFAULT nextval('work_request_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY work_scope ALTER COLUMN id SET DEFAULT nextval('work_scope_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY work_type ALTER COLUMN id SET DEFAULT nextval('work_type_id_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: pixelase
--

COPY address (id, street, house, apartment) FROM stdin;
\.
COPY address (id, street, house, apartment) FROM '$$PATH$$/2067.dat';

--
-- Name: address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pixelase
--

SELECT pg_catalog.setval('address_id_seq', 1, false);


--
-- Data for Name: brigade; Type: TABLE DATA; Schema: public; Owner: pixelase
--

COPY brigade (id, real_date, work_request_id) FROM stdin;
\.
COPY brigade (id, real_date, work_request_id) FROM '$$PATH$$/2079.dat';

--
-- Name: brigade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pixelase
--

SELECT pg_catalog.setval('brigade_id_seq', 1, false);


--
-- Data for Name: brigade_member; Type: TABLE DATA; Schema: public; Owner: pixelase
--

COPY brigade_member (brigade_id, employee_id) FROM stdin;
\.
COPY brigade_member (brigade_id, employee_id) FROM '$$PATH$$/2080.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: pixelase
--

COPY employee (id, first_name, last_name, work_type_id, salary) FROM stdin;
\.
COPY employee (id, first_name, last_name, work_type_id, salary) FROM '$$PATH$$/2073.dat';

--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pixelase
--

SELECT pg_catalog.setval('employee_id_seq', 1, false);


--
-- Data for Name: tenant; Type: TABLE DATA; Schema: public; Owner: pixelase
--

COPY tenant (id, first_name, last_name, address_id) FROM stdin;
\.
COPY tenant (id, first_name, last_name, address_id) FROM '$$PATH$$/2075.dat';

--
-- Name: tenant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pixelase
--

SELECT pg_catalog.setval('tenant_id_seq', 1, false);


--
-- Data for Name: work_request; Type: TABLE DATA; Schema: public; Owner: pixelase
--

COPY work_request (id, work_type_id, work_scope_id, desired_date, tenant_id) FROM stdin;
\.
COPY work_request (id, work_type_id, work_scope_id, desired_date, tenant_id) FROM '$$PATH$$/2077.dat';

--
-- Name: work_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pixelase
--

SELECT pg_catalog.setval('work_request_id_seq', 1, false);


--
-- Data for Name: work_scope; Type: TABLE DATA; Schema: public; Owner: pixelase
--

COPY work_scope (id, name, employees_count) FROM stdin;
\.
COPY work_scope (id, name, employees_count) FROM '$$PATH$$/2071.dat';

--
-- Name: work_scope_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pixelase
--

SELECT pg_catalog.setval('work_scope_id_seq', 1, false);


--
-- Data for Name: work_type; Type: TABLE DATA; Schema: public; Owner: pixelase
--

COPY work_type (id, name) FROM stdin;
\.
COPY work_type (id, name) FROM '$$PATH$$/2069.dat';

--
-- Name: work_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pixelase
--

SELECT pg_catalog.setval('work_type_id_seq', 1, false);


--
-- Name: pk_address_id; Type: CONSTRAINT; Schema: public; Owner: pixelase; Tablespace: 
--

ALTER TABLE ONLY address
    ADD CONSTRAINT pk_address_id PRIMARY KEY (id);


--
-- Name: pk_brigade_id; Type: CONSTRAINT; Schema: public; Owner: pixelase; Tablespace: 
--

ALTER TABLE ONLY brigade
    ADD CONSTRAINT pk_brigade_id PRIMARY KEY (id);


--
-- Name: pk_brigade_member_id; Type: CONSTRAINT; Schema: public; Owner: pixelase; Tablespace: 
--

ALTER TABLE ONLY brigade_member
    ADD CONSTRAINT pk_brigade_member_id PRIMARY KEY (brigade_id, employee_id);


--
-- Name: pk_employee_id; Type: CONSTRAINT; Schema: public; Owner: pixelase; Tablespace: 
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT pk_employee_id PRIMARY KEY (id);


--
-- Name: pk_tenant_id; Type: CONSTRAINT; Schema: public; Owner: pixelase; Tablespace: 
--

ALTER TABLE ONLY tenant
    ADD CONSTRAINT pk_tenant_id PRIMARY KEY (id);


--
-- Name: pk_work_request_id; Type: CONSTRAINT; Schema: public; Owner: pixelase; Tablespace: 
--

ALTER TABLE ONLY work_request
    ADD CONSTRAINT pk_work_request_id PRIMARY KEY (id);


--
-- Name: pk_work_scope_id; Type: CONSTRAINT; Schema: public; Owner: pixelase; Tablespace: 
--

ALTER TABLE ONLY work_scope
    ADD CONSTRAINT pk_work_scope_id PRIMARY KEY (id);


--
-- Name: pk_work_type_id; Type: CONSTRAINT; Schema: public; Owner: pixelase; Tablespace: 
--

ALTER TABLE ONLY work_type
    ADD CONSTRAINT pk_work_type_id PRIMARY KEY (id);


--
-- Name: fk_address_id; Type: FK CONSTRAINT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY tenant
    ADD CONSTRAINT fk_address_id FOREIGN KEY (address_id) REFERENCES address(id);


--
-- Name: fk_brigade_id; Type: FK CONSTRAINT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY brigade_member
    ADD CONSTRAINT fk_brigade_id FOREIGN KEY (brigade_id) REFERENCES brigade(id);


--
-- Name: fk_employee_id; Type: FK CONSTRAINT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY brigade_member
    ADD CONSTRAINT fk_employee_id FOREIGN KEY (employee_id) REFERENCES employee(id);


--
-- Name: fk_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY work_request
    ADD CONSTRAINT fk_tenant_id FOREIGN KEY (tenant_id) REFERENCES tenant(id);


--
-- Name: fk_work_request_id; Type: FK CONSTRAINT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY brigade
    ADD CONSTRAINT fk_work_request_id FOREIGN KEY (work_request_id) REFERENCES work_request(id);


--
-- Name: fk_work_scope_id; Type: FK CONSTRAINT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY work_request
    ADD CONSTRAINT fk_work_scope_id FOREIGN KEY (work_scope_id) REFERENCES work_scope(id);


--
-- Name: fk_work_type_employee_id; Type: FK CONSTRAINT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT fk_work_type_employee_id FOREIGN KEY (work_type_id) REFERENCES work_type(id);


--
-- Name: fk_work_type_id; Type: FK CONSTRAINT; Schema: public; Owner: pixelase
--

ALTER TABLE ONLY work_request
    ADD CONSTRAINT fk_work_type_id FOREIGN KEY (work_type_id) REFERENCES work_type(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

