--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.work_request DROP CONSTRAINT fk_work_type_id;
ALTER TABLE ONLY public.employee DROP CONSTRAINT fk_work_type_employee_id;
ALTER TABLE ONLY public.work_request DROP CONSTRAINT fk_work_scope_id;
ALTER TABLE ONLY public.brigade DROP CONSTRAINT fk_work_request_id;
ALTER TABLE ONLY public.work_request DROP CONSTRAINT fk_tenant_id;
ALTER TABLE ONLY public.tenant DROP CONSTRAINT fk_tenant_account_id;
ALTER TABLE ONLY public.account_role DROP CONSTRAINT fk_role_id;
ALTER TABLE ONLY public.brigade_member DROP CONSTRAINT fk_employee_id;
ALTER TABLE ONLY public.brigade_member DROP CONSTRAINT fk_brigade_id;
ALTER TABLE ONLY public.tenant DROP CONSTRAINT fk_address_id;
ALTER TABLE ONLY public.account_role DROP CONSTRAINT fk_account_id;
ALTER TABLE ONLY public.employee DROP CONSTRAINT fk_account_employee_id;
DROP INDEX public.fki_tenant_account_id;
DROP INDEX public.fki_account_employee_id;
ALTER TABLE ONLY public.role DROP CONSTRAINT uk_role_name;
ALTER TABLE ONLY public.account DROP CONSTRAINT uk_account_login;
ALTER TABLE ONLY public.account DROP CONSTRAINT uk_account_email;
ALTER TABLE ONLY public.role DROP CONSTRAINT uk_8sewwnpamngi6b1dwaa88askk;
ALTER TABLE ONLY public.work_type DROP CONSTRAINT pk_work_type_id;
ALTER TABLE ONLY public.work_scope DROP CONSTRAINT pk_work_scope_id;
ALTER TABLE ONLY public.work_request DROP CONSTRAINT pk_work_request_id;
ALTER TABLE ONLY public.tenant DROP CONSTRAINT pk_tenant_id;
ALTER TABLE ONLY public.role DROP CONSTRAINT pk_role_id;
ALTER TABLE ONLY public.employee DROP CONSTRAINT pk_employee_id;
ALTER TABLE ONLY public.brigade_member DROP CONSTRAINT pk_brigade_member_id;
ALTER TABLE ONLY public.brigade DROP CONSTRAINT pk_brigade_id;
ALTER TABLE ONLY public.address DROP CONSTRAINT pk_address_id;
ALTER TABLE ONLY public.account_role DROP CONSTRAINT pk_account_role_id;
ALTER TABLE ONLY public.account DROP CONSTRAINT pk_account_id;
ALTER TABLE public.work_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.work_scope ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.work_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tenant ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.role ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.employee ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.brigade ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.address ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.account ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.work_type_id_seq;
DROP TABLE public.work_type;
DROP SEQUENCE public.work_scope_id_seq;
DROP TABLE public.work_scope;
DROP SEQUENCE public.work_request_id_seq;
DROP TABLE public.work_request;
DROP SEQUENCE public.tenant_id_seq;
DROP TABLE public.tenant;
DROP SEQUENCE public.role_id_seq;
DROP TABLE public.role;
DROP SEQUENCE public.employee_id_seq;
DROP TABLE public.employee;
DROP TABLE public.brigade_member;
DROP SEQUENCE public.brigade_id_seq;
DROP TABLE public.brigade;
DROP SEQUENCE public.address_id_seq;
DROP TABLE public.address;
DROP TABLE public.account_role;
DROP SEQUENCE public.account_id_seq;
DROP TABLE public.account;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE account (
    id integer NOT NULL,
    login character varying(20) NOT NULL,
    email character varying NOT NULL,
    crypted_password character varying NOT NULL,
    first_name character varying,
    last_name character varying,
    birth_date date
);


ALTER TABLE account OWNER TO test;

--
-- Name: account_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE account_id_seq OWNER TO test;

--
-- Name: account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE account_id_seq OWNED BY account.id;


--
-- Name: account_role; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE account_role (
    account_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE account_role OWNER TO test;

--
-- Name: address; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE address (
    id integer NOT NULL,
    street character varying,
    house character varying,
    apartment character varying
);


ALTER TABLE address OWNER TO test;

--
-- Name: address_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE address_id_seq OWNER TO test;

--
-- Name: address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE address_id_seq OWNED BY address.id;


--
-- Name: brigade; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE brigade (
    id integer NOT NULL,
    real_date date,
    work_request_id integer NOT NULL
);


ALTER TABLE brigade OWNER TO test;

--
-- Name: brigade_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE brigade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE brigade_id_seq OWNER TO test;

--
-- Name: brigade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE brigade_id_seq OWNED BY brigade.id;


--
-- Name: brigade_member; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE brigade_member (
    brigade_id integer NOT NULL,
    employee_id integer NOT NULL
);


ALTER TABLE brigade_member OWNER TO test;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE employee (
    id integer NOT NULL,
    work_type_id integer,
    salary bigint,
    account_id integer NOT NULL
);


ALTER TABLE employee OWNER TO test;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE employee_id_seq OWNER TO test;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE employee_id_seq OWNED BY employee.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE role (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE role OWNER TO test;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE role_id_seq OWNER TO test;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE role_id_seq OWNED BY role.id;


--
-- Name: tenant; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE tenant (
    id integer NOT NULL,
    address_id integer,
    account_id integer NOT NULL
);


ALTER TABLE tenant OWNER TO test;

--
-- Name: tenant_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE tenant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tenant_id_seq OWNER TO test;

--
-- Name: tenant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE tenant_id_seq OWNED BY tenant.id;


--
-- Name: work_request; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE work_request (
    id integer NOT NULL,
    work_type_id integer NOT NULL,
    work_scope_id integer NOT NULL,
    desired_date date,
    tenant_id integer NOT NULL
);


ALTER TABLE work_request OWNER TO test;

--
-- Name: work_request_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE work_request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE work_request_id_seq OWNER TO test;

--
-- Name: work_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE work_request_id_seq OWNED BY work_request.id;


--
-- Name: work_scope; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE work_scope (
    id integer NOT NULL,
    name character varying,
    employees_count integer
);


ALTER TABLE work_scope OWNER TO test;

--
-- Name: work_scope_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE work_scope_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE work_scope_id_seq OWNER TO test;

--
-- Name: work_scope_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE work_scope_id_seq OWNED BY work_scope.id;


--
-- Name: work_type; Type: TABLE; Schema: public; Owner: test; Tablespace: 
--

CREATE TABLE work_type (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE work_type OWNER TO test;

--
-- Name: work_type_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE work_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE work_type_id_seq OWNER TO test;

--
-- Name: work_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE work_type_id_seq OWNED BY work_type.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY account ALTER COLUMN id SET DEFAULT nextval('account_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY address ALTER COLUMN id SET DEFAULT nextval('address_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY brigade ALTER COLUMN id SET DEFAULT nextval('brigade_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY employee ALTER COLUMN id SET DEFAULT nextval('employee_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY role ALTER COLUMN id SET DEFAULT nextval('role_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY tenant ALTER COLUMN id SET DEFAULT nextval('tenant_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY work_request ALTER COLUMN id SET DEFAULT nextval('work_request_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY work_scope ALTER COLUMN id SET DEFAULT nextval('work_scope_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY work_type ALTER COLUMN id SET DEFAULT nextval('work_type_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: test
--

COPY account (id, login, email, crypted_password, first_name, last_name, birth_date) FROM stdin;
\.
COPY account (id, login, email, crypted_password, first_name, last_name, birth_date) FROM '$$PATH$$/2104.dat';

--
-- Name: account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('account_id_seq', 11, true);


--
-- Data for Name: account_role; Type: TABLE DATA; Schema: public; Owner: test
--

COPY account_role (account_id, role_id) FROM stdin;
\.
COPY account_role (account_id, role_id) FROM '$$PATH$$/2106.dat';

--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: test
--

COPY address (id, street, house, apartment) FROM stdin;
\.
COPY address (id, street, house, apartment) FROM '$$PATH$$/2107.dat';

--
-- Name: address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('address_id_seq', 1, true);


--
-- Data for Name: brigade; Type: TABLE DATA; Schema: public; Owner: test
--

COPY brigade (id, real_date, work_request_id) FROM stdin;
\.
COPY brigade (id, real_date, work_request_id) FROM '$$PATH$$/2109.dat';

--
-- Name: brigade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('brigade_id_seq', 1, true);


--
-- Data for Name: brigade_member; Type: TABLE DATA; Schema: public; Owner: test
--

COPY brigade_member (brigade_id, employee_id) FROM stdin;
\.
COPY brigade_member (brigade_id, employee_id) FROM '$$PATH$$/2111.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: test
--

COPY employee (id, work_type_id, salary, account_id) FROM stdin;
\.
COPY employee (id, work_type_id, salary, account_id) FROM '$$PATH$$/2112.dat';

--
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('employee_id_seq', 10, true);


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: test
--

COPY role (id, name) FROM stdin;
\.
COPY role (id, name) FROM '$$PATH$$/2114.dat';

--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('role_id_seq', 3, true);


--
-- Data for Name: tenant; Type: TABLE DATA; Schema: public; Owner: test
--

COPY tenant (id, address_id, account_id) FROM stdin;
\.
COPY tenant (id, address_id, account_id) FROM '$$PATH$$/2116.dat';

--
-- Name: tenant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('tenant_id_seq', 1, true);


--
-- Data for Name: work_request; Type: TABLE DATA; Schema: public; Owner: test
--

COPY work_request (id, work_type_id, work_scope_id, desired_date, tenant_id) FROM stdin;
\.
COPY work_request (id, work_type_id, work_scope_id, desired_date, tenant_id) FROM '$$PATH$$/2118.dat';

--
-- Name: work_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('work_request_id_seq', 1, true);


--
-- Data for Name: work_scope; Type: TABLE DATA; Schema: public; Owner: test
--

COPY work_scope (id, name, employees_count) FROM stdin;
\.
COPY work_scope (id, name, employees_count) FROM '$$PATH$$/2120.dat';

--
-- Name: work_scope_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('work_scope_id_seq', 3, true);


--
-- Data for Name: work_type; Type: TABLE DATA; Schema: public; Owner: test
--

COPY work_type (id, name) FROM stdin;
\.
COPY work_type (id, name) FROM '$$PATH$$/2122.dat';

--
-- Name: work_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('work_type_id_seq', 6, true);


--
-- Name: pk_account_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT pk_account_id PRIMARY KEY (id);


--
-- Name: pk_account_role_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY account_role
    ADD CONSTRAINT pk_account_role_id PRIMARY KEY (account_id, role_id);


--
-- Name: pk_address_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY address
    ADD CONSTRAINT pk_address_id PRIMARY KEY (id);


--
-- Name: pk_brigade_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY brigade
    ADD CONSTRAINT pk_brigade_id PRIMARY KEY (id);


--
-- Name: pk_brigade_member_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY brigade_member
    ADD CONSTRAINT pk_brigade_member_id PRIMARY KEY (brigade_id, employee_id);


--
-- Name: pk_employee_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT pk_employee_id PRIMARY KEY (id);


--
-- Name: pk_role_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT pk_role_id PRIMARY KEY (id);


--
-- Name: pk_tenant_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY tenant
    ADD CONSTRAINT pk_tenant_id PRIMARY KEY (id);


--
-- Name: pk_work_request_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY work_request
    ADD CONSTRAINT pk_work_request_id PRIMARY KEY (id);


--
-- Name: pk_work_scope_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY work_scope
    ADD CONSTRAINT pk_work_scope_id PRIMARY KEY (id);


--
-- Name: pk_work_type_id; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY work_type
    ADD CONSTRAINT pk_work_type_id PRIMARY KEY (id);


--
-- Name: uk_8sewwnpamngi6b1dwaa88askk; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT uk_8sewwnpamngi6b1dwaa88askk UNIQUE (name);


--
-- Name: uk_account_email; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT uk_account_email UNIQUE (email);


--
-- Name: uk_account_login; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT uk_account_login UNIQUE (login);


--
-- Name: uk_role_name; Type: CONSTRAINT; Schema: public; Owner: test; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT uk_role_name UNIQUE (name);


--
-- Name: fki_account_employee_id; Type: INDEX; Schema: public; Owner: test; Tablespace: 
--

CREATE INDEX fki_account_employee_id ON employee USING btree (account_id);


--
-- Name: fki_tenant_account_id; Type: INDEX; Schema: public; Owner: test; Tablespace: 
--

CREATE INDEX fki_tenant_account_id ON tenant USING btree (account_id);


--
-- Name: fk_account_employee_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT fk_account_employee_id FOREIGN KEY (account_id) REFERENCES account(id);


--
-- Name: fk_account_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY account_role
    ADD CONSTRAINT fk_account_id FOREIGN KEY (account_id) REFERENCES account(id);


--
-- Name: fk_address_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY tenant
    ADD CONSTRAINT fk_address_id FOREIGN KEY (address_id) REFERENCES address(id);


--
-- Name: fk_brigade_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY brigade_member
    ADD CONSTRAINT fk_brigade_id FOREIGN KEY (brigade_id) REFERENCES brigade(id);


--
-- Name: fk_employee_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY brigade_member
    ADD CONSTRAINT fk_employee_id FOREIGN KEY (employee_id) REFERENCES employee(id);


--
-- Name: fk_role_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY account_role
    ADD CONSTRAINT fk_role_id FOREIGN KEY (role_id) REFERENCES role(id);


--
-- Name: fk_tenant_account_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY tenant
    ADD CONSTRAINT fk_tenant_account_id FOREIGN KEY (account_id) REFERENCES account(id);


--
-- Name: fk_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY work_request
    ADD CONSTRAINT fk_tenant_id FOREIGN KEY (tenant_id) REFERENCES tenant(id);


--
-- Name: fk_work_request_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY brigade
    ADD CONSTRAINT fk_work_request_id FOREIGN KEY (work_request_id) REFERENCES work_request(id);


--
-- Name: fk_work_scope_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY work_request
    ADD CONSTRAINT fk_work_scope_id FOREIGN KEY (work_scope_id) REFERENCES work_scope(id);


--
-- Name: fk_work_type_employee_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT fk_work_type_employee_id FOREIGN KEY (work_type_id) REFERENCES work_type(id);


--
-- Name: fk_work_type_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY work_request
    ADD CONSTRAINT fk_work_type_id FOREIGN KEY (work_type_id) REFERENCES work_type(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

